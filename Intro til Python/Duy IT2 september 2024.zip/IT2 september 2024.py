#Oppgave 1

import random
forbudtOrd = ["fis", "bæsj", "tis", "rompe"] #Forbudte ord
tegn = "!#¤%&/(" #Tegnene den ordet skal erstattes med

def nyOrd(ny): #Legge til nye fy-ord
    forbudtOrd.append(ny)
    
def fjernOrd(ordet): #Fjerne eksisterende fy-ord
     if ordet in forbudtOrd:
        forbudtOrd.remove(ordet)
    

def forbudt(string): #Funksjonen sjekker om et forbudt ord er i setningen og bytter den ut med tegn.
    for ord in forbudtOrd:
        if ord in string.lower():                             
            string = string.lower().replace(ord, random.choice(tegn) * len(ord)) 
    
    return string


text = "Den som fisen først er var, den er fisens rette far"
resultat = ' '.join([forbudt(i) for i in text.split()])             
print(resultat)


#Oppgave 2
land = [
    {"land": "Norge", "hovedstad": "Oslo", "innbyggere": 5_457_000, "naboland": ["sverige", "finnland","russland"]},
    {"land": "Sverige", "hovedstad": "Stockholm", "innbyggere": 10_490_000, "naboland": ["norge", "finnland"]},
    {"land": "Malaysia", "hovedstad": "Kuala Lumpur", "innbyggere": 33_940_000, "naboland": ["thailand", "vietnam","singapore","indonesia"]},
    {"land": "Canada", "hovedstad": "Ottowa", "innbyggere": 38_930_000, "naboland": ["usa", "russland"]}
]


svarInnbygger = int(input("Skriv inn innbyggertall:"))

for i in range(len(land)):
    if svarInnbygger == land[i]["innbyggere"]:
        print("Du er jammen god med tall!")
    elif svarInnbygger <= land[i]["innbyggere"] * 1.1 and svarInnbygger >= land[i]["innbyggere"] * 0.9:        
        print("Riktig svar!")
    else:
        print("Feil svar")