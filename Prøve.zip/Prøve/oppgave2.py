import tkinter as tk

temp = 0

def opp(): #Endrer global variabel opp
    global temp  
    temp += 0.5  
    melding = f"Temperatur: {temp}"
    temperatur.configure(text=melding)  
    
def ned(): #Endrer global variabel ned
    global temp  
    temp -= 0.5  
    melding = f"Temperatur: {temp}"
    temperatur.configure(text=melding)
    
def sett(): #Printer ut temp i label
    global temp
    melding = f"Temperaturen er satt til {temp}°C"
    resultat.configure(text=melding)

root = tk.Tk()

button1 = tk.Button(root, text="Av/På") #Lager knapp
button1.grid(row=0, column=0, rowspan=5, sticky="NS", padx=5, pady=5)

temperatur = tk.Label(root, text=f"Temperatur: {temp}", borderwidth=2, relief="solid") #Temperatur label
temperatur.grid(row=1, column=1, padx=5, pady=5)

tempOpp = tk.Button(root, text="↑", command=opp) #Knapp for temperatur opp, og bruker funksjonen opp
tempOpp.grid(row=0, column=2, padx=5, pady=5)

button2 = tk.Button(root, text="Sett", command= sett) #Knapp for å sette temp
button2.grid(row=1, column=2, rowspan=3, sticky="NS",padx=5, pady=5)

tempNed = tk.Button(root, text="↓", command=ned) #Knapp for temp ned
tempNed.grid(row=4, column=2, padx=5, pady=5)

resultat = tk.Label(bg='white', text="", borderwidth=2, relief='sunken') #Setter temp på slutten
resultat.grid(row=5,column=0,columnspan=4, sticky="EW", padx=6,pady=6)

root.mainloop()
