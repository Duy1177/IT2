import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("friluftsaktiviteter.csv", delimiter=";")
# verdier = df.value_counts()
# print(verdier.index.to_list())
# for aktivitet in df["friluftslivsaktivitet"]:
#     for _,j in df.iterrows():
#         if aktivitet in j["friluftslivsaktivitet"]: #Prøver å gå gjennom hver linje og summere 
#             sum(j)
#     print(j)

kolonner = df.columns.to_list()
kolonner.remove("friluftslivsaktivitet")
for fylke in kolonner:
    pd.to_numeric(df[fylke])

for fylkle in kolonner:
    summen = df[fylke].sum()
    print(summen)

#Her prøver jeg å få indeksen til å bli friluftlivsaktivitetene slik at jeg til slutt kan summere veridene for hver linje


# for fylke in df.columns:
#     print[df[fylke].values]
    
# kolonner = df.columns.tolist()
# kolonner.remove("friluftslivsaktivitet")
# # print(kolonner)


# df_visning = df[[kolonner]]
# df_visning.index = df["friluftslivsaktivitet"]
# print(df.head())

# # df.index = df["friluftslivsaktivitet"]
# # # print(df.iloc[3].values.tolist()) 
# # pd.to_numeric(df.columns.values(), errors="coerce")


fylke = input("Velg et fylke: ")
if fylke in df.columns:
    aktivitet = df.groupby("friluftslivsaktivitet")
    